package fr.eni.enchereEni.dal;

import fr.eni.enchereEni.bo.Utilisateur;

public interface UtilisateurDAO {
	
	Utilisateur rechercher();
	
}
