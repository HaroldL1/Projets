package fr.eni.enchereEni.dal;

import java.util.List;

import fr.eni.enchereEni.bo.Enchere;

public interface EnchereDAO {

	List<Enchere> findAll();
	
	

}
